/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hunpark <hunpark@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 17:58:21 by hunpark           #+#    #+#             */
/*   Updated: 2022/08/30 23:30:12 by hunpark          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

char	*ft_split_save(char **save, t_list **head, t_list **node)
{
	char	*str1;
	char	*str2;
	int		i;
	int		i2;

	i = ft_strchr(*save, '\n');
	if (i != -1 && (ft_strlen(*save) - i) > 1)
	{
		i2 = ft_strlen(*save) - i - 1;
		str1 = ft_substr(*save, 0, i + 1);
		str2 = ft_substr(*save, i + 1, i2);
		free(*save);
		*save = ft_strdup(str2);
		free(str2);
		*node = *head;
		return (str1);
	}
	else
	{
		str1 = ft_strdup(*save);
		free(*save);
		*save = NULL;
		*node = *head;
		return (str1);
	}
}

t_list	*ft_lst_new(int fd)
{
	t_list	*lst;

	lst = (t_list *)malloc(sizeof(t_list));
	if (!lst)
		return (NULL);
	lst->index_fd = fd;
	lst->next = NULL;
	lst->save = NULL;
	return (lst);
}

void	ft_lstadd_back(t_list **head, t_list **node, int fd)
{
	if (!(*head))
	{
		*head = ft_lst_new(fd);
		*node = *head;
		return ;
	}
	*node = *head;
	if ((*node)->index_fd == fd)
		return ;
	while ((*node)->index_fd != fd && (*node)->next != NULL)
	{
		(*node) = (*node)->next;
		if ((*node)->index_fd == fd)
			return ;
	}
	(*node)->next = ft_lst_new(fd);
	*node = (*node)->next;
	return ;
}

void	ft_free_lst(t_list **head, int fd)
{
	t_list	*tmp;
	t_list	*mov;

	if ((*head)->index_fd == fd)
	{
		tmp = (*head)->next;
		free(*head);
		*head = tmp;
		return ;
	}
	mov = *head;
	while (mov->next != NULL)
	{
		if (mov->next->index_fd == fd)
		{
			tmp = mov->next->next;
			free(mov->next);
			mov->next = tmp;
			return ;
		}
		mov = mov->next;
	}
}

char	*get_next_line(int fd)
{
	static t_list	*head;
	t_list			*node;
	char			buf[BUFFER_SIZE + 1];
	ssize_t			len;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	ft_lstadd_back(&head, &node, fd);
	len = read(fd, buf, BUFFER_SIZE);
	while (len > 0)
	{
		buf[len] = '\0';
		node->save = ft_strjoin(node->save, buf);
		if (ft_strchr(node->save, '\n') != -1)
			return (ft_split_save(&(node->save), &head, &node));
		len = read(fd, buf, BUFFER_SIZE);
	}
	if (node != NULL && !(node->save))
	{
		ft_free_lst(&head, fd);
		node = head;
		return (NULL);
	}
	return (ft_split_save(&(node->save), &head, &node));
}
